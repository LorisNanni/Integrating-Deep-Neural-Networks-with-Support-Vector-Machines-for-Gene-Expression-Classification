

## Included
- `top3_ensemble_clean.py`: Run Top3 (BaseKAN, FourierKAN, EfficientKAN) on a single dataset, for 10k or 30 features.
- `run_all_30_top3.py`: Run Top3 for all 16 datasets in 30-features mode.

These scripts are self-contained (no imports from project internals beyond standard folders).

## Requirements
- Python 3.9+
- `processed/` directory with dataset CSVs (e.g., `GSE13507_trasp_mod.csv`)
- `splits_kfold/` directory with predefined splits (e.g., `splits_kfold_Bladder Urothelial Carcinoma.txt`)
- `selected_features/` directory for 30-feature indices (e.g., `selected_features_Bladder Urothelial Carcinoma_1.txt`)
- Optional: `pykan` (otherwise the script falls back to a small MLP)

Install:
```bash
pip install -r requirements.txt
```

## run
### Single dataset (10k features)
```bash
python top3_ensemble_clean.py --cancer "Bladder Urothelial Carcinoma" --gse GSE13507 --mode 10k
```

### Single dataset (30 features)
```bash
python top3_ensemble_clean.py --cancer "Bladder Urothelial Carcinoma" --gse GSE13507 --mode 30
```

### All 17 datasets (30 features)
```bash
python run_top3_all_datasets.py
```

## Outputs
- 10k: `new_results__/10k_features/<dataset_slug_gse>/`
- 30: `new_results__/30_features/<dataset_slug>/`

Each fold produces:
- Per-model logits: `logits_{dataset}_{fold}_{model}`
- `summary.json` 

## notes
- Top3 is always the same three classifiers across all datasets: BaseKAN, FourierKAN, EfficientKAN (equal-weight average of logits, then softmax).
- Hyperparameters are the same for all datasets (no ad-hoc tuning): `epochs=50`, `batch_size=32`, `learning_rate=1e-3`, architecture `[input_dim, 32, 2]`.
- 10k mode: in each cross-validation fold, i run feature selection and standardization only on the training data, then apply those choices (the selected features and the fitted scaler) to the test data of that fold. This way, no information from the test set influences training, which prevents data leakage and makes the evaluation fair and realistic.
- 30 mode: fixed indices from `selected_features/` are applied consistently to both train and test.

## Example
```bash
python top3_ensemble_clean.py --cancer "Thyroid carcinoma" --gse GSE33630 --mode 30
```
This prints mean accuracies for BaseKAN/FourierKAN/EfficientKAN and for the Top3 ensemble, and writes logits/summary into `new_results__/30_features/thyroid_carcinoma/`.


