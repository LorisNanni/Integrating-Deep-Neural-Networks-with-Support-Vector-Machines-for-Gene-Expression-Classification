#!/usr/bin/env python3
"""
Run Top3 ensemble (30 features) for all 16 datasets.

Usage:
  python run_all_30_top3.py
"""

import subprocess


CANCER_TO_GSE = { 
    "Bladder Urothelial Carcinoma": "GSE13507",
    "Breast invasive carcinoma cancer": "GSE39004",
    "Breast cancer": "breast_matrix",
    "Colon adenocarcinoma": "GSE41657",
    "Esophageal carcinoma": "GSE20347",
    "Head and Neck squamous cell carcinoma": "GSE6631",
    "Kidney Chromophobe": "GSE15641_1",
    "Kidney renal clear cell carcinoma": "GSE15641_2",
    "Kidney renal papillary cell carcinoma": "GSE15641_3",
    "Liver hepatocellular carcinoma": "GSE45267",
    "Lung squamous cell carcinoma": "GSE33479",
    "Lung adenocarcinoma": "GSE10072",
    "Prostate adenocarcinoma": "GSE6919",
    "Rectum adenocarcinoma": "GSE20842",
    "Stomach adenocarcinoma": "GSE2685",
    "Thyroid carcinoma": "GSE33630",
    "Uterine Corpus Endometrial Carcinoma": "GSE17025"
}



def main() -> None:
    for cancer, gse in CANCER_TO_GSE.items():
        print("=" * 70)
        print(f"Running 30-features Top3 for: {cancer} ({gse})")
        cmd = [
            "python",
            "top3_ensemble_clean.py",
            "--cancer",
            cancer,
            "--gse",
            gse,
            "--mode",
            "30",
        ]
        print("Command:", " ".join(cmd))
        res = subprocess.run(cmd)
        if res.returncode != 0:
            print(f"FAILED: {cancer} ({gse})")
        else:
            print(f"DONE: {cancer} ({gse})")


if __name__ == "__main__":
    main()
