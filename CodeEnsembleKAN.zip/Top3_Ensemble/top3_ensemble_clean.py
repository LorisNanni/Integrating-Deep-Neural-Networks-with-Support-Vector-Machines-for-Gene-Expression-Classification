#!/usr/bin/env python3
"""
Usage examples:
  python top3_ensemble_clean.py --cancer "Bladder Urothelial Carcinoma" --gse GSE13507 --mode 10k
  python top3_ensemble_clean.py --cancer "Bladder Urothelial Carcinoma" --gse GSE13507 --mode 30
"""

import argparse
import json
from pathlib import Path
from typing import List, Tuple, Dict

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score
from sklearn.feature_selection import SelectKBest, chi2, f_classif
from sklearn.preprocessing import StandardScaler

import torch
import torch.nn as nn
import torch.optim as optim


try:
    from pykan import BaseKAN, FourierKAN, EfficientKAN, HybridKAN 
except Exception:
    BaseKAN = FourierKAN = EfficientKAN = HybridKAN = None  # type: ignore


class SimpleMLP(nn.Module):
    def __init__(self, input_dim: int, hidden: int = 32, dropout: float = 0.0):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, 2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def make_model_by_name(name: str, input_dim: int) -> nn.Module:
    # Build a small classifier with a single hidden layer (32 units)
    # If KAN models are available, we use them; otherwise we fall back to a simple MLP
    
    name_l = name.lower()
    if name_l == "basekan" and BaseKAN:
        return BaseKAN(layers=[input_dim, 32, 2])
    if name_l == "fourierkan" and FourierKAN:
        return FourierKAN(layers=[input_dim, 32, 2])
    if name_l == "efficientkan" and EfficientKAN:
        return EfficientKAN(layers=[input_dim, 32, 2])
    if name_l == "hybridkan" and HybridKAN:
        return HybridKAN(layers=[input_dim, 32, 2])

    return SimpleMLP(input_dim, hidden=32)


def train_and_predict_logits(
    model: nn.Module,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    epochs: int,
    batch_size: int,
    lr: float,
    device: str,
) -> np.ndarray:
    # Standard supervised training loop (cross-entropy + Adam)
    # Returns raw logits on the test split
    model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    X_train_t = torch.tensor(X_train, dtype=torch.float32)
    y_train_t = torch.tensor(y_train, dtype=torch.long)
    X_test_t = torch.tensor(X_test, dtype=torch.float32)

    train_ds = torch.utils.data.TensorDataset(X_train_t, y_train_t)
    train_loader = torch.utils.data.DataLoader(train_ds, batch_size=batch_size, shuffle=True)

    for _ in range(epochs):
        model.train()
        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            optimizer.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        logits = model(X_test_t.to(device))
    return logits.cpu().numpy()


def load_processed_matrix(processed_dir: str, gse: str) -> Tuple[np.ndarray, np.ndarray]:

    base = Path(processed_dir) / f"{gse}_trasp_mod.csv"
    if not base.exists():
        raise FileNotFoundError(f"{gse}_trasp_mod.csv not found in {processed_dir}")

    df = pd.read_csv(base, header=None)
    print(f"Original CSV shape: {df.shape}")  

    y = df.iloc[:, 0].astype(int).to_numpy()         
    X = df.drop(columns=0)                           
    X.columns = range(X.shape[1])                    
    X = X.to_numpy()

    print(f"Loaded X shape: {X.shape}, y shape: {y.shape}") 
    return X, y



def read_kfold_splits(kfold_file: str) -> List[Tuple[np.ndarray, np.ndarray]]:
    import re
    text = Path(kfold_file).read_text(encoding="utf-8")
    blocks = re.findall(r"\[([^\]]*?)\]", text)
    splits: List[Tuple[np.ndarray, np.ndarray]] = []
    for i in range(0, len(blocks), 2):
        if i + 1 >= len(blocks):
            break
        left = blocks[i]
        right = blocks[i + 1]
        train_idx = np.array([int(x) for x in left.replace("\n", " ").split() if x.strip().lstrip("-+").isdigit()], dtype=int)
        test_idx = np.array([int(x) for x in right.replace("\n", " ").split() if x.strip().lstrip("-+").isdigit()], dtype=int)
        splits.append((train_idx, test_idx))
    return splits


def read_selected_feature_indices(path: str, limit: int) -> List[int]:
    indices: List[int] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            indices.append(int(line))
            if len(indices) >= limit:
                break
    return indices


def sanitize_indices(idx: np.ndarray, n: int) -> np.ndarray:
    # Simple boundary check and deduplication
    if idx.size == 0:
        return idx
    idx = idx[(idx >= 0) & (idx < n)]
    return np.unique(idx)


def prepare_fold_data(
    X: np.ndarray,
    y: np.ndarray,
    tr: np.ndarray,
    te: np.ndarray,
    mode: str,
    cancer: str,
    fold_idx: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Prepares data for a single cross-validation fold.
    Uses exactly the given indices (no sanitization or removal).
    Performs feature selection and scaling safely (fit only on training data).
    """

    n_samples = len(y)
    assert X.shape[0] == n_samples, (
        f"Inconsistency: X has {X.shape[0]} rows but y has {n_samples} labels."
    )

    # Direct split
    X_tr, X_te = X[tr], X[te]
    y_tr, y_te = y[tr], y[te]

    print(f"[Fold {fold_idx}] train={len(y_tr)}  test={len(y_te)}")

    # --- Feature selection ---
    if mode == "30":
        sel_path = Path(f"selected_features/selected_features_{cancer}_{fold_idx}.txt")
        if not sel_path.exists():
            raise FileNotFoundError(f"Feature file not found: {sel_path}")
        idxs = read_selected_feature_indices(str(sel_path), 30)
        X_tr = X_tr[:, idxs]
        X_te = X_te[:, idxs]
    else:
        # 10k mode: fit selector on training data only
        try:
            selector = SelectKBest(score_func=chi2, k=min(10000, X_tr.shape[1]))
            X_tr = selector.fit_transform(X_tr, y_tr)
            X_te = selector.transform(X_te)
        except ValueError:
            # fallback if chi2 fails (e.g., negative values)
            selector = SelectKBest(score_func=f_classif, k=min(10000, X_tr.shape[1]))
            X_tr = selector.fit_transform(X_tr, y_tr)
            X_te = selector.transform(X_te)

    # --- Scaling (fit only on training data) ---
    scaler = StandardScaler()
    X_tr = scaler.fit_transform(X_tr)
    X_te = scaler.transform(X_te)

    return X_tr, y_tr, X_te, y_te



def main() -> None:
    parser = argparse.ArgumentParser(description="Run Top3 ensemble clean pipeline")
    parser.add_argument("--cancer", required=True, help="Cancer type name (exact, matches splits file)")
    parser.add_argument("--gse", required=True, help="GSE code, e.g. GSE13507")
    parser.add_argument("--mode", choices=["10k", "30"], default="10k", help="Feature mode")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--device", default=("cuda" if torch.cuda.is_available() else "cpu"))
    args = parser.parse_args()

    cancer = args.cancer
    gse = args.gse
    mode = args.mode
    epochs = args.epochs
    batch_size = args.batch_size
    lr = args.lr
    device = args.device

    print(f"Dataset: {cancer} ({gse}) | mode={mode} | device={device}")

    # Load data and splits
    # Note: folds are read from predefined files
    X, y = load_processed_matrix("processed", gse)

    splits = read_kfold_splits(f"splits_kfold/splits_kfold_{cancer}.txt")
    print(f"Samples={len(y)} | Folds={len(splits)}")

    # Output directory
    base_out = Path("results")
    if mode == "30":
        out_dir = base_out / "30_features"
    else:
        out_dir = base_out / "10k_features"

    # Crea cartella principale
    out_dir.mkdir(parents=True, exist_ok=True)

    # Crea sottocartella logits
    logits_dir = out_dir / "logits"
    logits_dir.mkdir(exist_ok=True)

    model_names = ["BaseKAN", "FourierKAN", "EfficientKAN"]
    per_model_fold_accs: Dict[str, List[float]] = {m: [] for m in model_names}
    top3_fold_accs: List[float] = []

    for fold_idx, (tr, te) in enumerate(splits):
        # Prepare train/test for this fold with leakage-safe preprocessing
        prep = prepare_fold_data(X, y, tr, te, mode, cancer, fold_idx + 1)
        if prep is None:
            continue
        X_tr, y_tr, X_te, y_te = prep

        per_model_logits: Dict[str, np.ndarray] = {}
        for mname in model_names:
            # Train each model and collect its test logits
            model = make_model_by_name(mname, input_dim=X_tr.shape[1])
            logits = train_and_predict_logits(model, X_tr, y_tr, X_te, epochs, batch_size, lr, device)
            per_model_logits[mname] = logits
            preds = np.argmax(logits, axis=1)
            acc = accuracy_score(y_te, preds)
            per_model_fold_accs[mname].append(acc)
            # Save per-model logits file
            with open(logits_dir / f"logits_{cancer}_{fold_idx+1}_{mname}.txt", "w") as f:
                for i in range(len(logits)):
                    f.write(f"{logits[i][0]:.6f} {logits[i][1]:.6f} {int(y_te[i])}\n")

        # Top3 ensemble
        # Average logits from BaseKAN, FourierKAN, EfficientKAN (equal weights)
        top3_logits = (
            per_model_logits["BaseKAN"] + per_model_logits["FourierKAN"] + per_model_logits["EfficientKAN"]
        ) / 3.0
        top3_preds = np.argmax(top3_logits, axis=1)
        top3_acc = accuracy_score(y_te, top3_preds)
        top3_fold_accs.append(top3_acc)
        """
        with open(logits_dir / f"logits_{cancer}_{fold_idx+1}_top3.txt", "w") as f:
            for i in range(len(top3_logits)):
                f.write(f"{top3_logits[i][0]:.6f} {top3_logits[i][1]:.6f} {int(y_te[i])}\n")
        """

    # Print per-model mean accuracies
    print("\nPer-model mean accuracies across folds:")
    for mname in model_names:
        accs = per_model_fold_accs[mname]
        if accs:
            print(f"  {mname}: {np.mean(accs):.4f} ± {np.std(accs):.4f}")
        else:
            print(f"  {mname}: N/A")

    # Print Top3 mean accuracy
    if top3_fold_accs:
        print(f"Top3 (BaseKAN+FourierKAN+EfficientKAN): {np.mean(top3_fold_accs):.4f} ± {np.std(top3_fold_accs):.4f}")
    else:
        print("Top3: N/A")

    summary = {
        "dataset": out_dir.name,
        "top3_accuracy_mean": float(np.mean(top3_fold_accs)) if top3_fold_accs else 0.0,
        "top3_accuracy_std": float(np.std(top3_fold_accs)) if top3_fold_accs else 0.0,
        "per_model_accuracy_mean": {m: (float(np.mean(per_model_fold_accs[m])) if per_model_fold_accs[m] else 0.0) for m in model_names},
        "per_model_accuracy_std": {m: (float(np.std(per_model_fold_accs[m])) if per_model_fold_accs[m] else 0.0) for m in model_names},
    }
    with open(out_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)


if __name__ == "__main__":
    main()


